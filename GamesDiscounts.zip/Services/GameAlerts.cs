﻿using GamesDiscounts.Bot;
using GamesDiscounts.Models;
using System.Threading.Tasks;
using Telegram.Bot.Types;

namespace GamesDiscounts.Services
{
    public class GameAlerts : IAlert
    {

        private readonly ISavedGamesService _savedGamesService;
        private CancellationTokenSource _cts = new CancellationTokenSource();
        private Dictionary<long, (Timer Timer, CancellationTokenSource Cts)> _timers = new();
        public event Func<long, List<GameDetailsDto>, Task> OnTimerElapsed;
        public bool alertsEnabled { get; set; } = false;
        public GameAlerts(ISavedGamesService savedGamesService)
        {
            
            _savedGamesService = savedGamesService;

        }
        public async Task SetTimer(long chatId, int PrecentDiscount = 0)
        {
            var alerts = await _savedGamesService.GetAllEnabledAlertsAsync();

            DailyAlerts(05, 34, chatId, PrecentDiscount);
        }

        public void DailyAlerts(int hour, int minute, long chatId, int PrecentDiscount = 0)
        {
            DateTime currentTime = DateTime.Now;
            DateTime nextRun = new DateTime(currentTime.Year, currentTime.Month, currentTime.Day, hour, minute, 0);

            if (currentTime > nextRun)
                nextRun = nextRun.AddDays(1);

            TimeSpan timeToGo = nextRun - currentTime;
            TimeSpan period = TimeSpan.FromMinutes(1);

            Console.WriteLine($"[INFO] Запускаем таймер для чата {chatId} на {timeToGo.TotalMinutes} минут");

            _cts = new CancellationTokenSource();

            Timer _timer = new Timer(async state =>
              {
                  if (_cts.IsCancellationRequested)
                  {
                      Console.WriteLine("[INFO] Таймер остановлен");
                      return;
                  }
                  long chatIdFromState = (long)state;
                  await EHandler(chatIdFromState);
              }, chatId, timeToGo, period);
            _timers[chatId] = (_timer, _cts);
        }
        public async Task EHandler(long chatId)
        {
            var handler = OnTimerElapsed;
            var alertSettings = await _savedGamesService.GetAlertAsync(chatId);
            if (alertState.IsEnabled && handler != null)
            {

                var games = await _savedGamesService.GetAlertGamesAsync(chatId, alertState.DiscountPercent);

                var tasks = handler
                    .GetInvocationList()
                    .Cast<Func<long, List<GameDetailsDto>, Task>>()
                    .Select(h => h(chatId, games));

                await Task.WhenAll(tasks);

            }

        }
        public void StopTimer(long chatId)
        {
            if (_timers.TryGetValue(chatId, out var entry))
            {
                entry.Cts.Cancel();
                entry.Timer.Dispose();
                _timers.Remove(chatId);
            }
        }
    }
}
