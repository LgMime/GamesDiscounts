﻿using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;

namespace GamesDiscounts.Bot
{

    public class TgBot
    {

        private readonly ITelegramBotClient _bot;
        private readonly CommandDispatcher _commandDispatcher;
   
        public TgBot(CommandDispatcher commandDispatcher, ITelegramBotClient bot)
        {
            _commandDispatcher = commandDispatcher;
            _bot = bot;
        }
        public async Task RunAsync()
        {

            var receiverOptions = new ReceiverOptions { AllowedUpdates = new UpdateType[] { UpdateType.Message, }, };
            _bot.StartReceiving(updateHandler, errorHandler, receiverOptions);
            await Task.Delay(-1);
        }

        private static async Task errorHandler(ITelegramBotClient bot, Exception exception, HandleErrorSource source, CancellationToken token)
        {
            throw new Exception($"An error occurred in the bot: {exception.Message}", exception);
        }

        private async Task updateHandler(ITelegramBotClient bot, Update update, CancellationToken token)
        {
            string someText = UpdateType.Message.ToString();
            var id = update.Message.Chat.Id;

            await _commandDispatcher.Dispatch(bot, update, token);

        }
    }
}
