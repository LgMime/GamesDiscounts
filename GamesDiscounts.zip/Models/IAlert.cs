﻿namespace GamesDiscounts.Models
{
    public interface IAlert
    {
        void SetTimer(long ChatId, int PrecentDiscount = 0);
        void StopTimer(long chatId);

        bool alertsEnabled { get; set; }
    }
}
